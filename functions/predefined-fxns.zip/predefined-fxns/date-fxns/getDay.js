const day=new Date();
console.log(day.getDay());
