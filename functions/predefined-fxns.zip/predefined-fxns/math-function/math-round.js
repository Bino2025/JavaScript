let num = Math.round(55.99);
console.log(num);
