const str ="hello"
const uppercase = str.toUpperCase();
console.log(uppercase);
