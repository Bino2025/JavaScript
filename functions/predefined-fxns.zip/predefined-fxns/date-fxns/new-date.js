//creates a new javascript date object represent the current date and time 

const none = new Date();
console.log(none);