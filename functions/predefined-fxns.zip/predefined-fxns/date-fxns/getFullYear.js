const full=new Date();
console.log(full.getFullYear());
