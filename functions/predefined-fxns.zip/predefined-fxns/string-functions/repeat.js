let text="ha";
console.log(text.repeat(2));
