const month=new Date();
console.log(month.getMonth());
