// round a num  to nearest whole number

let num=Math.floor(3.6);
console.log(num);

