//reomves white space from both ends of a string
let text=" hello "
console.log(text.trim());
