//retrieves the matches of the string against a regular expression
//match(regex)

let text = "the rain in spain stays mainly in the plain";
console.log(text.match(/ain/g));   //g-global scope
