// syntax---search(regex) 
//searches for a match between a regular expression and the string
let text = "the rain in spain stays mainly in the plain";
console.log(text.search("mainly"));
