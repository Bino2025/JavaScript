// round a num to 

let num=Math.ceil(5.9);
console.log(num);
