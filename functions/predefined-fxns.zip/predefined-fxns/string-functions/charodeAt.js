let str="h";
console.log(str.charCodeAt());
