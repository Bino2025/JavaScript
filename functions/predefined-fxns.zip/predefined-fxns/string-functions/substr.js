//extract a substring from a string
//syntax---substr(start,length);

let text = "hello, world"
// console.log(text.substr(7,5));
console.log(text.substring(7,12));
