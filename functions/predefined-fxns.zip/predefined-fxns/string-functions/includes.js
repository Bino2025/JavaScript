const str="hello";
const hassubstr=str.includes('b');
console.log(hassubstr);

