// generate random decimal num between 0 and 1 useful in games

let randomnum = Math.random(3.6);
console.log(randomnum);
