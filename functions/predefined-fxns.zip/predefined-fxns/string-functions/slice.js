const str ="hello"
const slicestr=str.slice(1,3);
console.log(slicestr);