//find the largest num----math.max
//find the min num ------math.min

let max = Math.max(3,5,10);
let min = Math.min(3,5,10);

console.log(max);
console.log(min);

