let str ="hello,  world!";
console.log(str.length);
