let str = "hello";
console.log(str.charAt(3));
